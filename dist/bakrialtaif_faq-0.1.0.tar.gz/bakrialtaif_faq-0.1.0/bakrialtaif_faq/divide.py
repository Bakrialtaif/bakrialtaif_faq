def divide(x, y):
    print("result is")
    return x/y