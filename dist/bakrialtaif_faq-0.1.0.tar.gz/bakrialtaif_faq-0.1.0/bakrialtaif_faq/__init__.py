from .divide import divide
from .multiply import multiply
"""
pyexample.

An example python library.
"""
__name__ = 'bakrialtaif_faq'
__version__ = "0.1.0"
__author__ = 'Bakri Altaif'
__credits__ = 'Argonne National Laboratory'
