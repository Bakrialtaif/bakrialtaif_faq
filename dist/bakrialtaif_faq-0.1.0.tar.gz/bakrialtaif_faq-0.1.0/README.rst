Funniest
--------

To use (with caution), simply do::

    >>> import bakrialtaif
